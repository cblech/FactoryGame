#include "$safeitemname$.h"
#include "GlobalDefines.h"
#include <iostream>
#include <SFML\System.hpp>

$safeitemname$::$safeitemname$(GameMap * map):GameObject(map)
{
	name = "Name of the Object";

	//the direction
	pointing = Direction::up;

	//size of the object
	size.x = 4;
	size.y = 7;

	//the main texture of the object
	texture.loadFromFile("car.png");
	
	//the position
	position.x = 5;
	position.y = 1;

	//Don't modify
	sprite.setTexture(texture);
	solveRotation();
}


$safeitemname$::~$safeitemname$()
{
}

//Drawing the Object
void $safeitemname$::draw(sf::RenderTarget & target, sf::RenderStates states) const
{
	//Add something under the default drawing
	
	GameObject::draw(target, states); //Default drawing
	
	//Add something above the default drawing
}

//Executes, when Object is Clicked
void $safeitemname$::click(sf::Event::MouseButtonEvent mouseEvent)
{
	std::cout << "Your Car: mouse click" << std::endl;
}

//Executes, when Mouse starts hovering the Object
void $safeitemname$::hoverStart(sf::Vector2i mousePosition)
{
	std::cout << "Your Car: mouse hover start" << std::endl;
}

//Executes, when Mouse stops hovering the Object
void $safeitemname$::hoverEnd(sf::Vector2i mousePosition)
{
	std::cout << "Your Car: mouse hover end" << std::endl;
}

