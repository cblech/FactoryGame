#include "$safeitemname$.h"
#include "GlobalDefines.h"
#include <iostream>
#include <SFML\System.hpp>

$safeitemname$::$safeitemname$(GameMap * map):GameObject(map)
{
	name = "Object Name";

	pointing = Direction::up;

	size.x = 2;
	size.y = 2;

	textureOffset = { -spaceSizePX,-spaceSizePX };

	mainTexture.loadFromFile("object.png");
	highlightTexture.loadFromFile("object_highlight.png");

	position.x = 0;
	position.y = 0;

	moveable = false;

	
	//Don't Modify
	mainSprite.setTexture(mainTexture);
	highlightSprite.setTexture(highlightTexture);
	solvePosition();
}


$safeitemname$::~$safeitemname$()
{
}

//Drawing the Object
void $safeitemname$::draw(sf::RenderTarget & target, sf::RenderStates states) const
{
	//Add something under the default drawing
	
	GameObject::draw(target, states); //Default drawing
	
	//Add something above the default drawing
}

void $safeitemname$::click(sf::Vector2i mousePosition)
{
	GameObject::click(mousePosition);
}

void $safeitemname$::clickStart(sf::Vector2i mousePosition)
{
	GameObject::clickStart(mousePosition);
}

void $safeitemname$::clickEnd(sf::Vector2i mousePosition)
{
	GameObject::clickEnd(mousePosition);
}

void $safeitemname$::hoverStart(sf::Vector2i mousePosition)
{
	GameObject::hoverStart(mousePosition);
}

void $safeitemname$::hoverEnd(sf::Vector2i mousePosition)
{
	GameObject::hoverEnd(mousePosition);
}

void $safeitemname$::holdStart(sf::Vector2i mousePosition)
{
	GameObject::holdStart(mousePosition);
}

void $safeitemname$::holdEnd(sf::Vector2i mousePosition)
{
	GameObject::holdEnd(mousePosition);
}

void $safeitemname$::rightClick(sf::Vector2i mousePosition)
{
	GameObject::rightClick(mousePosition);
}
